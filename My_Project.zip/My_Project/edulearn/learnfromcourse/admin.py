from django.contrib import admin
from learnfromcourse.models import CourseModel,SubmitConcerns


# Register your models here.
admin.site.register(CourseModel)
admin.site.register(SubmitConcerns)

