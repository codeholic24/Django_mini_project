from django.apps import AppConfig


class LearnfromcourseConfig(AppConfig):
    name = 'learnfromcourse'
