from django.contrib import admin
from django.urls import path
from learnfromcourse import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("", views.index,name='home'),
    path("video_list", views.video_list,name='list_of_video'),
    path("contact", views.contact,name='contact')
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
