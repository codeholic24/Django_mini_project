from django.shortcuts import render,HttpResponse
from learnfromcourse.models import CourseModel
from learnfromcourse.models import SubmitConcerns



# Create your views here.
def index(request):
   getdt=CourseModel.objects.all()
   return render(request,"index.html",{'getdet':getdt})

def video_list(request):
   return render(request,"video_list.html")

def contact(request):
   if request.method =='POST':
      Nms = request.POST.get('fname')
      Em  = request.POST.get('emailaddress')
      Cm  = request.POST.get('subjectmsg')
      ins = SubmitConcerns(SName=Nms,SEmail=Em ,SMsg= Cm)
      ins.save()
      return render(request,"Thanks.html")
   else:
      return render(request,"contact.html")

   





