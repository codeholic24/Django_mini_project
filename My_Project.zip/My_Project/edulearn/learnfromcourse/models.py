from django.db import models

# Create your models here.
class CourseModel(models.Model):
    CDescprition=models.TextField()
    CPhoto=models.ImageField(upload_to="pics")
    CLink=models.TextField(max_length=50, default="")    
    CName=models.TextField(max_length=50, default="")


class SubmitConcerns(models.Model):
    SName=models.TextField()
    SEmail=models.TextField()    
    SMsg=models.TextField()


class DynamicBannerImg(models.Model):
    BName=models.TextField()
    BPhoto=models.ImageField(upload_to="Banner_Imgs")
